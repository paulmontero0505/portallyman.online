import { createServer } from 'node:http'
import { mkdir, rm } from 'node:fs/promises'
import path from 'node:path'

const port = Number(process.env.PORT || 3002)
const host = process.env.HOST || '127.0.0.1'
const token = process.env.BAILEYS_API_TOKEN || ''
const authDir = path.join(process.cwd(), 'auth_info')
let socket = null, connected = false, reconnectTimer = null, latestQr = null, suppressReconnect = false
let deps = null, dependenciesError = null
const configured = token.length >= 24

// cPanel inicia la aplicación antes de ejecutar "NPM Install". Por ello ningún
// paquete externo se importa al arrancar: la ruta raíz queda disponible y cPanel
// permite instalar los módulos. Al reiniciar tras la instalación, se cargan aquí.
async function loadDependencies() {
  if (deps) return deps
  try {
    const [baileys, pinoModule, qrCodeModule, terminalModule] = await Promise.all([
      import('@whiskeysockets/baileys'), import('pino'), import('qrcode'), import('qrcode-terminal')
    ])
    deps = {
      ...baileys,
      logger: pinoModule.default({ level: process.env.LOG_LEVEL || 'info' }),
      QRCode: qrCodeModule.default,
      terminal: terminalModule.default
    }
    dependenciesError = null
    return deps
  } catch (error) {
    dependenciesError = 'Los módulos de WhatsApp aún no están instalados.'
    throw error
  }
}

async function connectWhatsApp() {
  const { default: makeWASocket, Browsers, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, useMultiFileAuthState, logger, terminal } = await loadDependencies()
  await mkdir(authDir, { recursive: true })
  const { state, saveCreds } = await useMultiFileAuthState(authDir)
  const { version } = await fetchLatestBaileysVersion()
  socket = makeWASocket({ version, auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) }, logger, browser: Browsers.ubuntu('Portally Tallyman'), printQRInTerminal: false, markOnlineOnConnect: false })
  socket.ev.on('creds.update', saveCreds)
  socket.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) { latestQr = qr; terminal.generate(qr, { small: true }) }
    if (connection === 'open') { connected = true; latestQr = null; console.log('WhatsApp conectado.') }
    if (connection === 'close') { connected = false; const loggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut; if (!loggedOut && !suppressReconnect) { clearTimeout(reconnectTimer); reconnectTimer = setTimeout(() => connectWhatsApp().catch(console.error), 3000) } }
  })
}
function json(res, status, body) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(body)) }
createServer(async (req, res) => {
  // Passenger normalmente elimina el prefijo de la URL de la aplicación, pero
  // algunos cPanel lo conservan. Se admite ambas formas para el puente v2.
  const rawPath = new URL(req.url, 'http://localhost').pathname.replace(/\/+$/, '') || '/'
  const route = rawPath.replace(/^\/whatsapp-bridge(?:-v2)?(?=\/|$)/, '') || '/'
  // cPanel/Passenger verifica la URL raíz de la aplicación antes de permitir
  // instalar dependencias. Esta respuesta no revela datos ni exige token.
  if (req.method === 'GET' && route === '/') return json(res, 200, { ok: true, service: 'portally-whatsapp-baileys', configured, connected, qrAvailable: Boolean(latestQr) })
  if (req.method === 'GET' && route === '/health') return json(res, 200, { ok: true, configured, connected, qrAvailable: Boolean(latestQr), dependenciesError })
  if (!configured) return json(res, 503, { ok: false, error: 'BAILEYS_API_TOKEN no está configurado' })
  if (req.headers.authorization !== `Bearer ${token}`) return json(res, 401, { ok: false, error: 'No autorizado' })
  if (req.method === 'GET' && route === '/qr') { if (!latestQr) return json(res, 404, { ok: false, error: 'No hay QR disponible' }); const { QRCode } = await loadDependencies(); return json(res, 200, { ok: true, svg: await QRCode.toString(latestQr, { type: 'svg', margin: 1, width: 300 }) }) }
  if (req.method === 'POST' && route === '/reset') { suppressReconnect = true; clearTimeout(reconnectTimer); connected = false; latestQr = null; await rm(authDir, { recursive: true, force: true }); socket?.ws?.close(); setTimeout(() => { suppressReconnect = false; connectWhatsApp().catch(console.error) }, 700); return json(res, 202, { ok: true }) }
  if (req.method !== 'POST' || route !== '/send-message') return json(res, 404, { ok: false })
  let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > 4096) return json(res, 413, { ok: false, error: 'Solicitud muy grande' }) }
  try { const { to, text } = JSON.parse(raw); if (!/^519\d{8}$/.test(String(to)) || typeof text !== 'string' || !text.trim() || text.length > 1400) return json(res, 422, { ok: false, error: 'Destino o mensaje inválido' }); if (!connected || !socket) return json(res, 503, { ok: false, error: 'WhatsApp no está conectado' }); const result = await socket.sendMessage(`${to}@s.whatsapp.net`, { text: text.trim() }); return json(res, 200, { ok: true, messageId: result?.key?.id || null }) } catch (error) { console.error('No se pudo enviar WhatsApp', error); return json(res, 502, { ok: false, error: 'No se pudo enviar el mensaje' }) }
}).listen(port, host, () => console.log(`Puente WhatsApp en http://${host}:${port}`))
if (configured) connectWhatsApp().catch(error => { console.error('No se pudo iniciar Baileys; instala los módulos y reinicia la aplicación.', error.message) })
else console.warn('BAILEYS_API_TOKEN no configurado: el puente inició sin sesión de WhatsApp.')
